# (Dataset Exploration Title)
## by (your name here)


## Dataset

> Provide basic information about your dataset in this section. If you selected your own dataset, make sure you note the source of your data and summarize any data wrangling steps that you performed before you started your exploration.

Prospor Load Data

[Loan Data](https://s3.amazonaws.com/udacity-hosted-downloads/ud651/prosperLoanData.csv)

[Prosper Data Dictionary to Explain Dataset's Variables](https://docs.google.com/spreadsheets/d/1gDyi_L4UvIrLTEC6Wri5nbaMmkGmLQBk-Yx3z0XDEtI/edit#gid=0)  

[extra Info](https://docs.google.com/document/d/e/2PACX-1vQmkX4iOT6Rcrin42vslquX2_wQCjIa_hbwD0xmxrERPSOJYDtpNc_3wwK_p9_KpOsfA6QVyEHdxxq7/pub)



## Summary of Findings

> Summarize all of your findings from your exploration here, whether you plan on bringing them into your explanatory presentation or not.


The current, and completed loans comprise the majority of the loans 
Income state seem to affect the defaulting rate
IsBorrowerHomeowner seems to be distributed evenly among all brrowers 

## Key Insights for Presentation

> Select one or two main threads from your exploration to polish up for your presentation. Note any changes in design from your exploration step here.

The income status not displayed contribute to increasing the loan defaulting rate.
